
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.menus.adminmenus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-12">
    <table class="table">
  <thead>
    <tr>
    <th scope="col">Product Name</th>
    <th scope="col">Visible</th>
    <th scope="col">Added Date</th>
     <th scope="col">  <button class="btn btn-block btn-warning" data-bs-toggle="modal" data-bs-target="#addproduct">Add Product</button> </th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($product->productname); ?></td>
      <th><?php echo e($product->visible); ?></th>
      <th><?php echo e($product->created_at); ?></th>
      
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<!----------ADD CAPITAL MODEL---------->
<div class="modal" tabindex="-1" id="addproduct">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">ADD PRODUCT</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(url('/addproduct')); ?>" method="post"  enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

            <div class="modal-body">

                    <input class="form-control mb-2" type="text" name="productname" id="" placeholder="Enter Product name" required>
                
                     </div>
            <div class="modal-footer">
            <button class="btn btn-success" type="submit">Create</button>
            </div>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make('includes.dashboardfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cznki\resources\views/admin/products/products.blade.php ENDPATH**/ ?>