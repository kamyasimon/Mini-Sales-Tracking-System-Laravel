<script>
setTimeout(function () {
        $("#flashmessage").hide();
    }, 4000);
 
  </script><?php /**PATH C:\wamp64\www\cznki\resources\views/includes/dashboardfooter.blade.php ENDPATH**/ ?>