
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.menus.adminmenus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(Auth::user()->fkrole == 2): ?>
<div class="row">
    <div class="col-12 d-flex justify-content-end">
      <button class="btn btn-block btn-warning" data-bs-toggle="modal" data-bs-target="#addsale">Sell</button>
     </div>
</div>
<?php endif; ?>
<div class="row" >
    <div class="col-12">
    <table class="table">
  <thead>
    <tr>
    <th scope="col">Company</th>
      <th scope="col">Item Sold</th>
      <th scope="col">Stock Key</th>
      <th scope="col">Quantity Sold</th>
      <th scope="col">Amount sold</th>
      <th scope="col">Expe Purpose</th>
      
      <th scope="col">Exp Amount</th>
      <th scope="col">Total</th>
      <th scope="col">Order Status</th>
      
     
    
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td>
      <?php if($sale->handedover == false ): ?>
     <a href="<?php echo e(url('handedover',[$sale->id])); ?>" style="color:red !important"> <?php echo e($sale->Companies->companyname); ?></a>
    <?php elseif($sale->handedover == true ): ?>
    <p style="color:purple !important"><?php echo e($sale->Companies->companyname); ?>: <strong> Received<strong></p>
    <?php endif; ?>
    </td>
      <td><?php echo e($sale->Products->productname); ?></td>
      <td><?php echo e($sale->stockid); ?></td>
      <td><?php echo e($sale->quantitysold); ?></td>
      <td><?php echo e($sale->amountsold); ?></td>
      <td><?php echo e($sale->expenditure); ?></td>
      <td><?php echo e($sale->expenditureamount); ?></td>
      <td><?php echo e($sale->totalprice); ?></td>
      <td><?php echo e($sale->orderstatus); ?></td>
     
      <?php if($sale->orderstatus == 'pending' && Auth::user()->fkrole == 2): ?>
      <td>
        <a href="<?php echo e(url('delivered',[$sale->id])); ?>"> <button class="btn btn-warning">Delivered</button></a>
      </td>
      <?php elseif($sale->orderstatus == 'delivered' && Auth::user()->fkrole == 2): ?>
      <td>
      <a href="<?php echo e(url('paid',[$sale->id])); ?>">  <button class="btn btn-success">Paid</button></a>
      </td>
      <?php elseif($sale->orderstatus == 'paid'): ?>
      <td>
        <p>Completed</p>
      </td>
      <?php endif; ?>
     
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>

  </div>
  
</div>


<?php $__env->stopSection(); ?>

<!----------ADD CAPITAL MODEL---------->
<div class="modal" tabindex="-1" id="addsale">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Sell Product</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(url('/addsale')); ?>" method="post"  enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

            <div class="modal-body">
          <select class="form-control mb-2" name="company" id="">
            <option value="">Select Company</option>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($company->id); ?>"><?php echo e($company->companyname); ?></option>
           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>

          <select class="form-control mb-2" name="product" >
                <option value="">Select Product</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                <option value="<?php echo e($product->id); ?>"><?php echo e($product->productname); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <select class="form-control mb-2" name="batch" id="">
                <option value="">Select Batch</option>
                <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                <option value="<?php echo e($batch->id); ?>"><?php echo e($batch->batch); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <select class="form-control mb-2" name="stockid" id="">
                <option value="">Select Stock</option>
                <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($stock->availablestock > 0): ?>
                <option value="<?php echo e($stock->stockid); ?>"><?php echo e($stock->stockid); ?>: <?php echo e($stock->Companies->companyname); ?> : <?php echo e($stock->availablestock); ?> <strong style="color:green"><?php echo e($stock->Products->productname); ?> available</strong></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
                    <input class="form-control mb-2" type="number" name="quantitysold" id="" min='0' placeholder="Input Sold Quantity" required>
                    
                    <input class="form-control mb-2" type="number" name="saleprice" id="" min='0' placeholder="Input Sales Price" required>
                    <input class="form-control mb-2" type="text" name="expenditure" id="" placeholder="Enter Expenditure Purpose" required>
                    <input class="form-control mb-2" type="number" name="expenditureamount" id="" min='0' placeholder="Input Expenditure" required>
            </div>
            <div class="modal-footer">
            <button class="btn btn-success" type="submit">Sell</button>
            </div>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make('includes.dashboardfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cznki\resources\views/admin/sales/sales.blade.php ENDPATH**/ ?>