
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.menus.adminmenus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
<?php if(Auth::user()->fkrole == 2): ?>
  <div class="col-12 d-flex justify-content-around align-items-center">
 
      <button class="btn btn-block btn-success" data-bs-toggle="modal" data-bs-target="#addstock">Add Stock</button>
        <button class="btn btn-block btn-success" data-bs-toggle="offcanvas" data-bs-target="#createstockbatch" >Create Stock Batch</button> 
   
  </div>
  <?php endif; ?>
</div>
<hr>
<div class="row">
    <div class="col-12">
    <table class="table">
  <thead>
    <tr>
    <th scope="col">Stock Batch</th>
    <th scope="col">Stock Id</th>
    <th scope="col">Stock Company</th>
    <th scope="col">Item Stocked</th>
    <th scope="col">Stock Quantity</th>
    <th scope="col">Stock Amount</th>
    <th scope="col">Stock Price</th>
    <th scope="col">Sale Price</th>
    <th scope="col">projected Profits</th>
    <th scope="col">available</th>
    <th scope="col">stockdate</th>
   
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th><?php echo e($stock->Batches->batch); ?></th>
      <th><?php echo e($stock->stockid); ?></th>
      <th><?php echo e($stock->Companies->companyname); ?></th>
      <th><?php echo e($stock->Products->productname); ?></th>
      <td><?php echo e($stock->stockquantity); ?></td>
      <td><?php echo e($stock->stockamount); ?></td>
      <td><?php echo e($stock->stockprice); ?></td>
      <td><?php echo e($stock->saleprice); ?></td>
      <td><?php echo e($stock->projectedprofits); ?></td>
      <?php if($stock->availablestock == 0): ?>
      <td  style = "color:red">Out of Stock</td>
      <?php elseif(($stock->availablestock /$stock->availablestock)*100 < 30): ?>
      <td style = "color:orange"><?php echo e($stock->availablestock); ?> remaining</td>
      <?php else: ?>
      <td style = "color:green"><?php echo e($stock->availablestock); ?> available</td>
      <?php endif; ?>
      <td><?php echo e($stock->created_at); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<!----------ADD BATCH MODEL---------->
<div class="offcanvas offcanvas-start" tabindex="-1" id="createstockbatch">
  
<div class="offcanvas-header">
  
    <h5 class="offcanvas-title" id="offcanvasExampleLabel">Create Stock Batch</h5>
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  
     
  </div>
  <div class="offcanvas-body">
     
      
    <form action="<?php echo e(url('/addstockbatch')); ?>" method="post"  enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="row">
            <div class='col-8'>
                    <input class="form-control mb-2" type="text" name="batch" id="" placeholder="e.g: batch1/JAN/2022" required>
            </div>
            <div class='col-4' >
            <button class="btn btn-success btn-sm" type="submit">Create Batch</button>
            </div>
            </div> 
      </form>
    <div class="row">
      <div class="col-12">
        <ul>
        <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($batch->batch); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
</div>
  
</div>


<!----------ADD STOCK MODEL---------->
<div class="modal" tabindex="-1" id="addstock">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Stock</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(url('/addstock')); ?>" method="post"  enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

            <div class="modal-body">
              <select class="form-control mb-2" name="fkcompany" id="">
                <option value="">Select Company</option>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                <option value="<?php echo e($company->id); ?>"><?php echo e($company->companyname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <select class="form-control mb-2" name="batch" id="">
                    <option value="">Select Batch</option>
                    <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($batch->id); ?>"><?php echo e($batch->batch); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <select class="form-control mb-2" name="product" id="">
                <option value="">Select Product</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                <option value="<?php echo e($product->id); ?>"><?php echo e($product->productname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
                    <input class="form-control mb-2" type="number" name="quantity" id="" min='0' placeholder="Input Stock Quantity" required>
                    <input class="form-control mb-2" type="number" name="stockprice" id="" min='0' placeholder="Input Stock Price" required>
                    <input class="form-control mb-2" type="number" name="saleprice" id="" min='0' placeholder="Input Sales Price" required>
            </div>
            <div class="modal-footer">
            <button class="btn btn-success" type="submit">Add Stock</button>
            </div>
      </form>
    </div>
  </div>
</div>
<?php echo $__env->make('includes.dashboardfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cznki\resources\views/admin/stock/stocks.blade.php ENDPATH**/ ?>