
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.menus.adminmenus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-12">
    <table class="table">
  <thead>
    <tr>
    <th scope="col">Name</th>
    <th scope="col">Email</th>
      <th>Fk Role</th>
      
     
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($user->name); ?></td>
      <th><?php echo e($user->email); ?></th>
      <td><?php echo e($user->fkrole); ?></td>
      <form action="<?php echo e(url('addrole',[$user->id])); ?>" method="post">
      <?php echo e(csrf_field()); ?>

      <td><input class="form-control" type="number" name="addrole" id="" min="1" max="5" required></td>
      <td><button class="form-control btn btn-primary">Update Role</button></td>
      </form>
     
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cznki\resources\views/admin/users/users.blade.php ENDPATH**/ ?>