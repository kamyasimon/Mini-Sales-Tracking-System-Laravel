
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.menus.adminmenus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-12">
    <table class="table">
  <thead>
    <tr>
    <th scope="col">Company Name</th>
    <th scope="col">Company Admin</th>
     <th scope="col">  <button class="btn btn-block btn-warning" data-bs-toggle="modal" data-bs-target="#addcompany">Add Company</button> </th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($company->companyname); ?></td>
      <th><?php echo e($company->User->name); ?></th>
      
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<!----------ADD CAPITAL MODEL---------->
<div class="modal" tabindex="-1" id="addcompany">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">ADD COMPANY</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(url('/addcompany')); ?>" method="post"  enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

            <div class="modal-body">

                    <input class="form-control mb-2" type="text" name="companyname" id="" placeholder="Enter company name" required>
                   <select class="form-control mb-2" name="fkadmin" id="">
                       <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value=" ">Select Company Admin</option>
                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
                     </div>
            <div class="modal-footer">
            <button class="btn btn-success" type="submit">Create</button>
            </div>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make('includes.dashboardfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cznki\resources\views/admin/companies/companies.blade.php ENDPATH**/ ?>