<script>
setTimeout(function () {
        $("#flashmessage").hide();
    }, 4000);
 
  </script>