
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.menus.adminmenus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-12">
    <table class="table">
  <thead>
    <tr>
    <th scope="col">Company</th>
      <th scope="col">Item Sold</th>
      <th scope="col">Quantity Sold</th>
      <th scope="col">Amount sold</th>
      <th scope="col">Cust Name</th>
      <th scope="col">CustNumber</th>
      <th scope="col">Expe Purpose</th>
      
      <th scope="col">Exp Amount</th>
      <th scope="col">Total</th>
      <th scope="col">Order Status</th>
      
     
     
      <th scope="col">  <button class="btn btn-block btn-warning" data-bs-toggle="modal" data-bs-target="#addsale">Sell</button> </th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($sale->company); ?></td>
      <th ><?php echo e($sale->itemsold); ?></th>
      <td><?php echo e($sale->quantitysold); ?></td>
      <td><?php echo e($sale->amountsold); ?></td>
      <td><?php echo e($sale->customername); ?></td>
      <td><?php echo e($sale->customernumber); ?></td>
      <td><?php echo e($sale->expenditure); ?></td>
      <td><?php echo e($sale->expenditureamount); ?></td>
      <td><?php echo e($sale->totalprice); ?></td>
      <td><?php echo e($sale->orderstatus); ?></td>
      <?php if($sale->orderstatus == 'pending'): ?>
      <td>
        <a href="<?php echo e(url('delivered',[$sale->id])); ?>"> <button class="btn btn-warning">Delivered</button></a>
      </td>
      <?php elseif($sale->orderstatus == 'delivered'): ?>
      <td>
      <a href="<?php echo e(url('paid',[$sale->id])); ?>">  <button class="btn btn-success">Paid</button></a>
      </td>
      <?php elseif($sale->orderstatus == 'paid'): ?>
      <td>
        <p>Completed</p>
      </td>
      <?php endif; ?>
     
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<!----------ADD CAPITAL MODEL---------->
<div class="modal" tabindex="-1" id="addsale">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Sell Product</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(url('/addsale')); ?>" method="post"  enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

            <div class="modal-body">
          <select class="form-control mb-2" name="company" id="">
          <option value="CZNKI">CZNKI</option>
            <option value="GB SACCO">GB SACCO</option>
          </select>

                    <input class="form-control mb-2" type="text" name="itemsold" id="" placeholder="Enter Sold Item">
                    <input class="form-control mb-2" type="number" name="quantitysold" id="" min='0' placeholder="Input Sold Quantity">
                    
                    <input class="form-control mb-2" type="number" name="saleprice" id="" min='0' placeholder="Input Sales Price">
                    <input class="form-control mb-2" type="text" name="expenditure" id="" placeholder="Enter Expenditure Purpose">
                    <input class="form-control mb-2" type="number" name="expenditureamount" id="" min='0' placeholder="Input Expenditure">
            </div>
            <div class="modal-footer">
            <button class="btn btn-success" type="submit">Sell</button>
            </div>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make('includes.dashboardfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cznki\resources\views/admin/sales/sales.blade.php ENDPATH**/ ?>