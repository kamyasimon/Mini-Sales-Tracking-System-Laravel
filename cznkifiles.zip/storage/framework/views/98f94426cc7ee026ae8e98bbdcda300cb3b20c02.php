
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.menus.adminmenus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-12">
    <table class="table">
  <thead>
    <tr>
     
      <th scope="col">Item Stocked</th>
      <th scope="col">Stock Quantity</th>
      <th scope="col">Stock Amount</th>
      <th scope="col">Stock Price</th>
      <th scope="col">Sale Price</th>
      <th scope="col">projected Sales</th>
     
      <th scope="col">  <button class="btn btn-block btn-success" data-bs-toggle="modal" data-bs-target="#addstock">Add Stock</button> </th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th ><?php echo e($stock->itemstocked); ?></th>
      <td><?php echo e($stock->stockquantity); ?></td>
      <td><?php echo e($stock->stockamount); ?></td>
      <td><?php echo e($stock->stockprice); ?></td>
      <td><?php echo e($stock->saleprice); ?></td>
      <td><?php echo e($stock->projectedsales); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<!----------ADD CAPITAL MODEL---------->
<div class="modal" tabindex="-1" id="addstock">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Stock</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(url('/addstock')); ?>" method="post"  enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

            <div class="modal-body">
                    <input class="form-control mb-2" type="text" name="stockitem" id="" placeholder="Enter Stock Item">
                    <input class="form-control mb-2" type="number" name="quantity" id="" min='0' placeholder="Input Stock Quantity">
                    <input class="form-control mb-2" type="number" name="stockprice" id="" min='0' placeholder="Input Stock Price">
                    <input class="form-control mb-2" type="number" name="saleprice" id="" min='0' placeholder="Input Sales Price">
            </div>
            <div class="modal-footer">
            <button class="btn btn-success" type="submit">Add Stock</button>
            </div>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make('includes.dashboardfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cznki\resources\views/admin/stock/stocks.blade.php ENDPATH**/ ?>