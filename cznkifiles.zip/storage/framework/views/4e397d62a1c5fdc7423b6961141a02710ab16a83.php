<div class="row fixed-top" id="flashmessage">
          <div class="col-12 ">
        <?php echo $__env->make('includes.partials.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('includes.partials.danger', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('includes.partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
</div>
<?php /**PATH C:\wamp64\www\cznki\resources\views/includes/dashboardheader.blade.php ENDPATH**/ ?>