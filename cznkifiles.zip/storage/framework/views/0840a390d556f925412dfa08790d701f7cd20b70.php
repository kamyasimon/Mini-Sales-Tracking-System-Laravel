
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.menus.adminmenus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-12">
    <table class="table">
  <thead>
    <tr>
    <th scope="col">Customer Name</th>
    <th scope="col">Customer Number</th>
      <th scope="col">Items Purchased</th>
      <th scope="col">Amount Loaned</th>
      <th scope="col">Amount Paid</th>
      <th scope="col">Amount Balance</th>
      <th scope="col">Loan Status</th>
      <th scope="col">  <button class="btn btn-block btn-warning" data-bs-toggle="modal" data-bs-target="#addloan">Loan Products</button> </th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($loan->customername); ?></td>
      <th><?php echo e($loan->customernumber); ?></th>
      <td><?php echo e($loan->itemspurchased); ?></td>
      <td><?php echo e($loan->amountloaned); ?></td>
      <td><?php echo e($loan->amountpaid); ?></td>
      <td><?php echo e($loan->amountbalance); ?></td>
      <td><?php echo e($loan->loanstatus); ?></td>
      <?php if($loan->loanstatus !== 'completed'): ?>
      <form action="<?php echo e(url('payloan',[$loan->id])); ?>" method="post">
      <?php echo e(csrf_field()); ?>

      <td><input class="form-control" type="number" name="payloan" id="" min="100" required></td>
      <td><button class="form-control btn btn-primary">Pay</button></td>
      </form>
      <?php else: ?>
      <td> <p style="color:green">Payment Fully Completed</p></td>
      <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<!----------ADD CAPITAL MODEL---------->
<div class="modal" tabindex="-1" id="addloan">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">LOAN PRODUCTS</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(url('/addloan')); ?>" method="post"  enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

            <div class="modal-body">

                    <input class="form-control mb-2" type="text" name="customername" id="" placeholder="Enter customer name">
                    <input class="form-control mb-2" type="text" name="customernumber" id="" placeholder="Enter customer number">
                    <textarea class="form-control mb-2" name="itemspurchased" id="" cols="30" rows="10" placeholder="Enter Detailed Product values on loan"></textarea>
                    <input class="form-control mb-2" type="number" name="amountloaned" id="" min='0' placeholder="Input Loan Amount">
                     </div>
            <div class="modal-footer">
            <button class="btn btn-success" type="submit">Loan</button>
            </div>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make('includes.dashboardfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cznki\resources\views/admin/loans/loans.blade.php ENDPATH**/ ?>